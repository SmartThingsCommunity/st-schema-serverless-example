(async function() {
	const db = require('../lib/db');
	const deviceService = require('../lib/device-service');

	const device = await db.getDevice('bob@smartthings.com', '59b080d4-b89d-491a-b675-1213d1fcf627');
	await deviceService.addDevice('bob@smartthings.com', device)
})();
